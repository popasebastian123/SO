# city_manager - phase 1

## descriere
program in c care simuleaza un sistem de raportare si monitorizare a problemelor de infrastructura urbana.

inspectori si manageri pot adauga, vizualiza si gestiona rapoarte despre probleme din diferite districte (drumuri, iluminat, inundatii etc).

---

## functionalitati implementate

- creare si gestionare districte (directoare separate)
- stocare rapoarte in fisier binar (reports.dat)
- afisare lista rapoarte
- vizualizare raport individual
- stergere raport (manager only)
- actualizare prag severitate (manager only)
- filtrare rapoarte dupa conditii
- logarea tuturor actiunilor
- creare link simbolic catre fisierul de rapoarte

---

## structura proiect
